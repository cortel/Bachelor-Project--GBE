﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (Roles.IsUserInRole(HttpContext.Current.User.Identity.Name, "Admin"))
            Response.Redirect("~/Admin/AdminAccount.aspx");
        else if (Roles.IsUserInRole(HttpContext.Current.User.Identity.Name, "TaskDoer "))
            Response.Redirect("~/TaskDoer/TaskDoerAccount.aspx");
        else if (Roles.IsUserInRole(HttpContext.Current.User.Identity.Name, "TaskPoster "))
            Response.Redirect("~/TaskPoster/TaskPosterAccount.aspx");
    }
}
