﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TaskDoer_AddSkill : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        // Gets the default connection string/path to our database from the web.config file
        string dbstring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        // Creates a connection to our database
        SqlConnection con = new SqlConnection(dbstring);

        // The SQL statement to insert a booking. By using prepared statements,
        // we automatically get some protection against SQL injection.
        string sqlStr = "INSERT INTO Skills (task_section,skills_type, skills_experience, hourly_rate) VALUES (@section, @type, @experience, @rate)";

        // Open the database connection
        con.Open();

        // Create an executable SQL command containing our SQL statement and the database connection
        SqlCommand sqlCmd = new SqlCommand(sqlStr, con);

        // Fill in the parameters in our prepared SQL statement
        sqlCmd.Parameters.AddWithValue("@section", section_box.Text);
        sqlCmd.Parameters.AddWithValue("@type", type_box.Text);
        sqlCmd.Parameters.AddWithValue("@experience", experience_box.Text);
        sqlCmd.Parameters.AddWithValue("@rate", Convert.ToInt32(rate_box.Text));

        // Execute the SQL command
        sqlCmd.ExecuteNonQuery();


        SqlCommand comm = new SqlCommand("select IDENT_CURRENT('Skills')", con);
        int newSkillId = Convert.ToInt32(comm.ExecuteScalar());



        string sqlStr2 = "INSERT INTO SkillsUser (skills_id,username) VALUES (@skills, @username)";

        SqlCommand sqlCmd2 = new SqlCommand(sqlStr2, con);
        sqlCmd2.Parameters.AddWithValue("@skills", newSkillId);
        sqlCmd2.Parameters.AddWithValue("@username", this.User.Identity.Name);

        sqlCmd2.ExecuteNonQuery();

        // Close the connection to the database
        con.Close();
    }
}