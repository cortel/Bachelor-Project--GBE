﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TaskPoster_AssignDoer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["TaskId"]);

       string doerName =  GridView1.SelectedDataKey.Value.ToString();




       // Gets the default connection string/path to our database from the web.config file
       string dbstring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

       // Creates a connection to our database
       SqlConnection con = new SqlConnection(dbstring);

       // The SQL statement to insert a booking. By using prepared statements,
       // we automatically get some protection against SQL injection.
       string sqlStr = "UPDATE Task set doer_id = @doer_id WHERE task_id = @id";

       // Open the database connection
       con.Open();

       // Create an executable SQL command containing our SQL statement and the database connection
       SqlCommand sqlCmd = new SqlCommand(sqlStr, con);

       // Fill in the parameters in our prepared SQL statement


       sqlCmd.Parameters.AddWithValue("@doer_id", doerName);
       sqlCmd.Parameters.AddWithValue("@id", id);
       
       // Execute the SQL command
       sqlCmd.ExecuteNonQuery();



       con.Close();


       Response.Redirect("~/TaskPoster/TaskPosterAccount.aspx");



    }
}