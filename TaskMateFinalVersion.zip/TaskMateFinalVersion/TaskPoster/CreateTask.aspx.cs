﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TaskPoster_CreateTask : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        // Gets the default connection string/path to our database from the web.config file
        string dbstring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        // Creates a connection to our database
        SqlConnection con = new SqlConnection(dbstring);

        // The SQL statement to insert a booking. By using prepared statements,
        // we automatically get some protection against SQL injection.
        string sqlStr = "INSERT INTO Task (poster_id,task_section,task_zipcode, task_address, task_description, task_datetime) VALUES (@poster_id, @section, @zipcode, @address, @description, @datetime)";

        // Open the database connection
        con.Open();

        // Create an executable SQL command containing our SQL statement and the database connection
        SqlCommand sqlCmd = new SqlCommand(sqlStr, con);

        // Fill in the parameters in our prepared SQL statement


        sqlCmd.Parameters.AddWithValue("@poster_id", this.User.Identity.Name);
        sqlCmd.Parameters.AddWithValue("@section", task_section_box.Text);
        sqlCmd.Parameters.AddWithValue("@zipcode", task_zipcode_box.Text);
        sqlCmd.Parameters.AddWithValue("@address", task_address_box.Text);
        sqlCmd.Parameters.AddWithValue("@description", task_description_box.Text);
        sqlCmd.Parameters.AddWithValue("@datetime", task_datetime_box.Text);

        // Execute the SQL command
        sqlCmd.ExecuteNonQuery();


        SqlCommand comm = new SqlCommand("select IDENT_CURRENT('Task')", con);
        int newTaskId = Convert.ToInt32(comm.ExecuteScalar());


        con.Close();

        Session["TaskId"] = newTaskId;

        Response.Redirect("~/TaskPoster/AssignDoer.aspx");
    }
}